# D Lexical Analizer

## REQUIREMENTS

If you want to use this script to execute the program, you need to have installed the following applications:

1. **make** - sudo apt-get install make
2. **cmake** - sudo apt-get install cmake

## HOW TO USE IT

1. Open a terminal
2. Go to the directory where is located **ejecutar.bash**
3. To run the program type

    bash ejecutar.bash